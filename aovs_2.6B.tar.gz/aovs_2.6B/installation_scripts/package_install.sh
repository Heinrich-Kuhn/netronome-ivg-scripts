#!bin/bash
#package_install.sh

dpkg -i *.deb
