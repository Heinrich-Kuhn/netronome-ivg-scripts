#!/bin/bash

apt-get -y install netperf
